BiocGenerics:::testPackage("KEGGREST")
